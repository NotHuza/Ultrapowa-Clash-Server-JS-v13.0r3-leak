const net = require("net");
const chalk = require('chalk')
const factory = require('./factory')
const fs = require('fs')


const server = new net.Server()

